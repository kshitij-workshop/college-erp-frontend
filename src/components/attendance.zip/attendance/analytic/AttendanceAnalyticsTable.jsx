import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import AttendanceAnalyticsRow from "./AttendanceAnalyticsRow";

export default function AttendanceAnalyticsTable({
  students,
  subjectOfferingId,
  onView,
}) {
  if (!students.length) {
    return (
      <div className="rounded-2xl border border-dashed bg-white py-16 text-center">
        <h3 className="text-lg font-semibold">No students found</h3>

        <p className="mt-2 text-sm text-muted-foreground">
          Try another search.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">

      <Table>

      <TableHeader className="bg-slate-50">
  <TableRow>

    <TableHead>Student</TableHead>

    <TableHead className="text-center">
      Present
    </TableHead>

    <TableHead className="text-center">
      Absent
    </TableHead>

    <TableHead className="text-center">
      Total
    </TableHead>

    <TableHead className="text-center">
      Attendance
    </TableHead>

    <TableHead className="text-right">
      Action
    </TableHead>

  </TableRow>
</TableHeader>

        <TableBody>

          {students.map(student => (

            <AttendanceAnalyticsRow
              key={student.studentId}
              student={student}
              subjectOfferingId={subjectOfferingId}
              onView={onView}
            />

          ))}

        </TableBody>

      </Table>

    </div>
  );
}