import { useMemo, useState } from "react";

import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

import { useAuth } from "@/hooks/useAuth";

import AttendanceAnalyticsTable from "@/components/attendance/analytic/AttendanceAnalyticsTable";

import AdminAnalyticsFilter from "@/components/attendance/analytic/filters/AdminAnalyticsFilter";
import FacultyAnalyticsFilter from "@/components/attendance/analytic/filters/FacultyAnalyticsFilter";

import AdminStudentAttendanceDialog from "@/components/attendance/analytic/dialog/AdminStudentAttendanceDialog";
import StudentSubjectAttendanceDialog from "@/components/attendance/analytic/dialog/StudentSubjectAttendanceDialog";

export default function AttendanceAnalytics() {
  const { user } = useAuth();

  const [students, setStudents] = useState([]);

  const [loading, setLoading] = useState(false);

  const [search, setSearch] = useState("");

  const [selectedStudent, setSelectedStudent] = useState(null);

  const [selectedSubject, setSelectedSubject] = useState(null);

  const [detailsOpen, setDetailsOpen] = useState(false);

  const [historyOpen, setHistoryOpen] = useState(false);

  function handleView(student) {
    setSelectedStudent(student);
    setDetailsOpen(true);
  }

  const filteredStudents = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    return students.filter(
      (student) =>
        student.studentName.toLowerCase().includes(keyword) ||
        String(student.registrationNumber).includes(keyword)
    );
  }, [students, search]);

  return (
    <div className="space-y-6">

      {user.role === "ADMIN" ? (
        <AdminAnalyticsFilter
          setStudents={setStudents}
          setLoading={setLoading}
        />
      ) : (
        <FacultyAnalyticsFilter
          setStudents={setStudents}
          setLoading={setLoading}
          setSelectedSubject={setSelectedSubject}
        />
      )}

      <div className="relative">

        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />

        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search student..."
          className="pl-10"
        />

      </div>

      <AttendanceAnalyticsTable
        students={filteredStudents}
        loading={loading}
        onView={handleView}
      />

      {user.role === "ADMIN" ? (
        <AdminStudentAttendanceDialog
          open={detailsOpen}
          onOpenChange={setDetailsOpen}
          student={selectedStudent}
        />
      ) : (
        <StudentSubjectAttendanceDialog
          open={detailsOpen}
          onOpenChange={setDetailsOpen}
          studentId={selectedStudent?.studentId}
          subjectOfferingId={selectedSubject}
        />
      )}

    </div>
  );
}