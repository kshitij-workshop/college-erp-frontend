export default function StudentSubjectAttendanceDialog(){
    return null;
}