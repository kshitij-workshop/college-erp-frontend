import { useEffect, useState } from "react";
import {
  User,
  GraduationCap,
  Percent,
  BookOpen,
} from "lucide-react";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

import { getStudentOverallAttendance } from "@/api/attendanceApi";

export default function AdminStudentAttendanceDialog({
  open,
  onOpenChange,
  student,
}) {
  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(false);

  const [historyOpen, setHistoryOpen] = useState(false);

const [selectedSubject, setSelectedSubject] = useState(null);

function handleViewHistory(subject) {

    setSelectedSubject(subject);

    setHistoryOpen(true);

}

  useEffect(() => {
    async function load() {
      if (!open || !student) return;

      try {
        setLoading(true);

        const response = await getStudentOverallAttendance(
          student.studentId
        );

        setDetails(response.data.data);

      } finally {
        setLoading(false);
      }
    }

    load();
  }, [open, student]);

  if (!student) return null;

  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-3xl">

        <DialogHeader>

          <DialogTitle className="text-2xl">
            Student Attendance
          </DialogTitle>

        </DialogHeader>

        {loading ? (

          <div className="py-16 text-center text-muted-foreground">
            Loading attendance...
          </div>

        ) : details && (

          <div className="space-y-8">

            {/* Student */}

            <div className="grid gap-4 md:grid-cols-2">

              <div className="rounded-2xl border bg-slate-50 p-5">

                <div className="flex items-center gap-2 text-slate-500">

                  <User className="h-4 w-4" />

                  Student

                </div>

                <p className="mt-2 text-lg font-semibold">
                  {details.studentName}
                </p>

                <p className="text-sm text-muted-foreground">
                  {details.registrationNumber}
                </p>

              </div>

              <div className="rounded-2xl border bg-slate-50 p-5">

                <div className="flex items-center gap-2 text-slate-500">

                  <Percent className="h-4 w-4" />

                  Overall Attendance

                </div>

                <p className="mt-2 text-3xl font-bold text-blue-600">

                  {details.overallPercentage.toFixed(1)}%

                </p>

                <p className="text-sm text-muted-foreground">

                  {details.presentClasses} / {details.totalClasses} Classes

                </p>

              </div>

            </div>

            {/* Progress */}

            <Progress
              value={details.overallPercentage}
              className="h-3"
            />

            <Separator />

            {/* Subject Summary */}

            <div>

              <div className="mb-4 flex items-center gap-2">

                <BookOpen className="h-5 w-5" />

                <h3 className="text-lg font-semibold">
                  Subject-wise Attendance
                </h3>

              </div>

              <div className="space-y-3">

                {details.subjects.map((subject) => (

                 <button
                        key={subject.subjectOfferingId}
                        type="button"
                        onClick={() => handleViewHistory(subject)}
                        className="flex w-full items-center justify-between rounded-2xl border p-4 text-left transition hover:border-blue-200 hover:bg-blue-50"
                >

                    <div>

                      <p className="font-medium">

                        {subject.subjectName}

                      </p>

                      <p className="text-sm text-muted-foreground">

                        {subject.subjectCode}

                      </p>

                    </div>

                    <div className="text-right">

                      <Badge variant="secondary">

                        {subject.presentClasses} / {subject.totalClasses}

                      </Badge>

                      <p className="mt-2 font-semibold text-blue-600">

                        {subject.percentage.toFixed(1)}%

                      </p>

                    </div>

                  
                  </button>

                ))}

              </div>

            </div>

          </div>

        )}

      </DialogContent>
    </Dialog>
  );
}